﻿function getCode(username, password) {
    if (username.length !== password.length && username.length > 0 && password.length > 0) {
        alert('Длина имени пользователя и пароля не совпадают!');
        return String('');
    }

    const str = getBaseString();
    const nums = '0123456789';
    let res = Bar();
    let check = Foo();
    let code = '';
    let pos1 = -1;
    let pos2 = -1;
    let letter = '';

    for (let i = 0; i < username.length; i++) {
        //pos1 = nums.indexOf(username[i]) >= 0 ? nums.indexOf(username[i]) : str.indexOf(username[i]);
        //pos2 = nums.indexOf(password[i]) >= 0 ? nums.indexOf(password[i]) : str.indexOf(password[i]);
        pos1 = str.indexOf(username[i]);
        pos2 = nums.indexOf(password[i]);

        if (pos1 === -1 || pos2 === -1) {
            code += '-';
        }
        else {
            letter = str[(pos1 + pos2) % str.length];
            if (letter === Foo(i))
                code += letter.toUpperCase();
            else
                code += letter;
        }
    }
    if (code.toLowerCase() === check.toLowerCase()) {
        return res;
    }
    else {
        return code;
    }

}