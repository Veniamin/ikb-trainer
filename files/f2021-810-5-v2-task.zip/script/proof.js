function getBaseString() {
    return 'thequickbrownfxjmpsvlazydg';
}

function forgetCode() {
    const arr = [9, 4, 6, 21, 22, 7, 11];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(100 + arr[i]);
    }
    return res;
}



function Bar() {
    const arr = [67, 110, 98, 98, 54, 27, 76, 104, 91, 98, 91, 105];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(arr[i] + i);
    }
    return res;
};

function Foo(n = -1) {
    const arr = [122, 101, 108, 116, 100, 120, 111];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(arr[i]);
    }
    if (n === -1)
        return res;
    if (n >= 0 && n < arr.length)
        return res[n];
    return '-';
}
