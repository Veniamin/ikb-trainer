function getBaseString() {
    return 'alfredojustmybingvxchwqkpz';
}

function forgetCode() {
    const arr = [22, 6, 9, 7, 4, 3, 19];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(100 + arr[i]);
    }
    return res;
}



function Bar() {
    const arr = [67, 110, 98, 98, 54, 27, 62, 107, 89, 94, 101, 99, 90, 95, 107];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(arr[i] + i);
    }
    return res;
};

function Foo(n = -1) {
    const arr = [51, 54, 69, 44, 50, 58, 57];
    let res = '';
    for (let i = 0; i < arr.length; i++) {
        res = res + String.fromCharCode(arr[i] + 50 + i);
    }
    if (n === -1)
        return res;
    if (n >= 0 && n < arr.length)
        return res[n];
    return '-';
}
