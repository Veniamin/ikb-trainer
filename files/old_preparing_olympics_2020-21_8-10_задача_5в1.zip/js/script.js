
window.addEventListener('load', function () {

    login_btn = document.getElementById('login_btn');
    code_label = document.getElementById('code_label');
    login_form = document.getElementById('login_form');
    forgot_code_btn = document.getElementById('forgot_code_btn');
    username_form = document.getElementById('username_form');
    passwd_form = document.getElementById('passwd_form');
    remember_me_btn = document.getElementById('remember_me_btn')

    forgot_code_btn.addEventListener('click', function () {

        window.alert(getBaseString()+'\n01234567890123456789012345')
    }, false);

}, false);

remember_me_btn.addEventListener('click', function () {

    window.alert(forgetCode());

}, false);

function myfunc() {
    let code = '';
    if (username_form.value && passwd_form.value)
        code = getCode(username_form.value, passwd_form.value);
    if (code && code.length > 0)
        code_label.innerText = code;
    else
        code_label.innerText = 'ВОЙТИ';
}


login_btn.addEventListener('click', function () {
    myfunc();
    return false;
}, false);



